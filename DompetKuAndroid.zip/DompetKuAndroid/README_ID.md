# DompetKu Pro — Android WebView

Proyek Android ini membungkus `app/src/main/assets/index.html` menggunakan WebView. JavaScript dan DOM storage diaktifkan agar navigasi, localStorage, dan penyimpanan data aplikasi dapat bekerja.

## Membuat APK
1. Salin/ekstrak folder `DompetKuAndroid` ke komputer yang memiliki Android Studio.
2. Buka folder proyek tersebut di Android Studio.
3. Pastikan Android SDK Platform 35 terpasang, lalu tunggu Gradle Sync selesai.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Ini adalah proyek sumber Android, bukan APK hasil kompilasi. APK belum dikompilasi di sini karena lingkungan ini tidak menyediakan Android SDK/Gradle build environment.
- Data transaksi disimpan di localStorage WebView pada perangkat. Jangan menghapus data aplikasi jika ingin mempertahankan data.
- Google Fonts dan gambar profil online membutuhkan koneksi internet; fitur inti halaman dimuat dari file lokal.

## Alternatif build dari HP dengan GitHub Actions
1. Buat repository GitHub baru dan unggah seluruh isi folder proyek ini (termasuk folder `.github`).
2. Buka tab **Actions**, pilih workflow **Build DompetKu APK**, lalu tekan **Run workflow**.
3. Setelah selesai, buka hasil run dan unduh artifact **DompetKu-Pro-debug-apk**. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.
4. Instal APK di HP. Android mungkin meminta izin **Install unknown apps** untuk aplikasi yang kamu gunakan menginstal APK.
